﻿$Extract_Folder_Path = "C:\Windows\Temp\BIOS_Extract"
$BIOS_Extract_Sources = "$Extract_Folder_Path\Extract_BIOS_Sources"
$User_Continue_Process_File = "$Extract_Folder_Path\BIOS_Update_Continue.txt"
$WPF_Warning_Export_Folder = "C:\Windows\Temp\WPF_Warning"

If(!(test-path $Extract_Folder_Path)){new-item $Extract_Folder_Path -type Directory -force}

$Get_MTM = ((Get-CimInstance Win32_ComputerSystem).Model.SubString(0, 4)).Trim()
$Log_File = "$env:SystemDrive\Windows\Debug\Remediation_BIOS_Update_$Get_MTM.log"
If(!(test-path $Log_File)){new-item $Log_File -type file -force}

Function Write_Log
	{
		param(
		$Message_Type,	
		$Message
		)
		
		$MyDate = "[{0:MM/dd/yy} {0:HH:mm:ss}]" -f (Get-Date)
		Add-Content $Log_File  "$MyDate - $Message_Type : $Message"
		write-host  "$MyDate - $Message_Type : $Message"
	}
	
If(test-path $User_Continue_Process_File)
	{							
		Write_Log -Message_Type "INFO" -Message "The user validate the update process"	
		Write_Log -Message_Type "INFO" -Message "Suspending Bitlocker"
		
		$Check_Bitlocker_Status = Get-BitLockerVolume -MountPoint $env:SystemDrive | Select-Object -Property ProtectionStatus
		If ($Check_Bitlocker_Status.ProtectionStatus -eq "On") 
			{
				Try
					{
						Suspend-BitLocker -MountPoint $env:SystemDrive  -RebootCount 1 | out-null
						$Suspend_Bitlocker_Success = $True
						Write_Log -Message_Type "SUCCESS" -Message "Suspending Bitlocker"
						Write_Log -Message_Type "SUCCESS" -Message "Bitlocker will be anabled again at next reboot"
					}
				Catch
					{
						Write_Log -Message_Type "ERROR" -Message "Suspending Bitlocker"	
						EXIT
					}
			}	
		Else
			{
				$Suspend_Bitlocker_Success = $True
				Write_Log -Message_Type "SUCCESS" -Message "Bitlocker not enabled"
			}
						
		# Si Bitlocker a été arrête avec succès, on met à jour le BIOS
		If($Suspend_Bitlocker_Success -eq $True)
			{
				$BIOS_Extract_Sources = "C:\Windows\Temp\BIOS_Extract"
				
				# BIOS Update installer silent switch
				$Silent_Switch = "-s"
				# Path of the BIOS installer
				$WINUTP_Install_Path = "$BIOS_Extract_Sources\$WINUTP_Installer"
				# BIOS Update log name
				$WINUTP_Log_File = "winuptp.log"
				# BIOS Update log path
				$WINUTP_Log_Path = "$BIOS_Extract_Sources\$WINUTP_Log_File"
				If(!(test-path "$BIOS_Extract_Sources\WINUPTP64.exe"))
					{
						If(test-path "$BIOS_Extract_Sources\WINUPTP.exe")
							{
								$WINUTP_Installer = "WINUPTP.exe"
							}
					}
				Else
					{
						$WINUTP_Installer = "WINUPTP64.exe"
					}
				
				If(test-path $WINUTP_Install_Path)
					{
						Write_Log -Message_Type "INFO" -Message "Updating BIOS update"
						Write_Log -Message_Type "INFO" -Message "Chemin de la mise à jour: $BIOS_Extract_Sources\$WINUTP_Installer"	

						$Update_Process = Start-Process -FilePath $WINUTP_Installer -WorkingDirectory $BIOS_Extract_Sources -ArgumentList $Silent_Switch -PassThru -Wait
						If(($Update_Process.ExitCode) -eq 1) 
							{
								Write_Log -Message_Type "INFO" -Message "Checking update state in log file"
								If(test-path $WINUTP_Log_Path)
									{			
										$Check_BIOSUpdate_Status_FromLog = ((Get-content $WINUTP_Log_Path | where-object { $_ -like "*BIOS Flash completed*"}) -ne "")		
										If($Check_BIOSUpdate_Status_FromLog -ne $null)
											{
												Write_Log -Message_Type "SUCCESS" -Message "Updating BIOS"
														Write_Log -Message_Type "INFO" -Message "Reboot pending"
												start-process -WindowStyle hidden powershell.exe "$WPF_Warning_Export_Folder\Restart_Computer.ps1" -Wait	
												Remove-item $BIOS_Update_Folder -Force -Recurse
												
												copy-item $Log_File "C:\Windows\Debug\BIOS_Update_Completes.log"
												clear-content $Log_File -force
												
												$BIOS_Update_Success_File = "C:\Windows\Debug\BIOS_Update_Success_File.txt"
												new-item $BIOS_Update_Success_File -type file -force
												
												Break
											}
										Else
											{
												Write_Log -Message_Type "ERROR" -Message "Updating BIOS"
												Break
											}
									}
								Else
									{
										Write_Log -Message_Type "SUCCESS" -Message "File not found: $WINUTP_Log_Path"
									}
							}	
						Else
							{
								Write_Log -Message_Type "ERROR" -Message "Updating BIOS"
								Break
							}
					}
				Else
					{
						Write_Log -Message_Type "INFO" -Message "BIOS installer not found: $WINUTP_Install_Path"
					}
			}
	}