﻿$Global:Current_Folder = split-path $MyInvocation.MyCommand.Path

[System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')  				| out-null
[System.Reflection.Assembly]::LoadWithPartialName('presentationframework') 				| out-null
[System.Reflection.Assembly]::LoadFrom("$Current_Folder\assembly\MahApps.Metro.dll")       				| out-null
[System.Reflection.Assembly]::LoadFrom("$Current_Folder\assembly\MahApps.Metro.IconPacks.dll")      | out-null  

function LoadXml ($global:filename)
{
	$XamlLoader=(New-Object System.Xml.XmlDocument)
	$XamlLoader.Load($filename)
	return $XamlLoader
}

$XamlMainWindow=LoadXml("$Current_Folder\Warning_BIOS.xaml")

$Reader=(New-Object System.Xml.XmlNodeReader $XamlMainWindow)
$Form=[Windows.Markup.XamlReader]::Load($Reader)

$Main_Title = $Form.findname("Main_Title") 
$Part1 = $Form.findname("Part1") 
$Part2 = $Form.findname("Part2") 
$Part3 = $Form.findname("Part3") 
$Part4 = $Form.findname("Part4") 

$OD_Migration_Btn_Previous = $Form.findname("OD_Migration_Btn_Previous") 
$OD_Migration_Btn_Next = $Form.findname("OD_Migration_Btn_Next") 
$Previous_Button = $Form.findname("Previous_Button") 
$Main_Buttons = $Form.findname("Main_Buttons") 
$FlipView = $Form.findname("FlipView") 
$Later_Btn = $Form.findname("Later_Btn") 

$FlipView.IsBannerEnabled = $false
$FlipView.IsNavigationEnabled = $false
$FlipView.LeftTransition = 0
		
$Main_Buttons.Margin = "-144,0,0,0"

$Extract_Folder_Path = "C:\Windows\Temp\BIOS_Extract"
$User_Continue_Process_File = "$Extract_Folder_Path\BIOS_Update_Continue.txt"

$Get_MTM = ((Get-CimInstance Win32_ComputerSystem).Model.SubString(0, 4)).Trim()
$Log_File = "$env:SystemDrive\Windows\Debug\Remediation_BIOS_Update_$Get_MTM.log"
If(!(test-path $Log_File)){new-item $Log_File -type file -force}

Function Write_Log
	{
		param(
		$Message_Type,	
		$Message
		)
		
		$MyDate = "[{0:MM/dd/yy} {0:HH:mm:ss}]" -f (Get-Date)		
		Add-Content $Log_File  "$MyDate - $Message_Type : $Message"		
		write-host  "$MyDate - $Message_Type : $Message"		
	}

Write_Log -Message_Type "INFO" -Message "Opening the user warning"			

$FlipView.Add_SelectionChanged({
	Switch ($FlipView.SelectedIndex) 
		{ 
			0 
			{   		
				$Part1.Background="#EE9C76"
				$Part1.BorderBrush="#EE9C76"
				
				$Part2.Background="#D4D4D4"
				$Part2.BorderBrush="#D4D4D4"

				$OD_Migration_Btn_Previous.Content = "Previous"
				$OD_Migration_Btn_Next.Content = "Next"				
				$Previous_Button.IsEnabled = $False	
			}

			1 
			{ 
				$Part1.Background="#D4D4D4"
				$Part1.BorderBrush="#D4D4D4"
				
				$Part2.Background="#EE9C76"
				$Part2.BorderBrush="#EE9C76"

				$OD_Migration_Btn_Previous.Content = "Previous"
				$OD_Migration_Btn_Next.Content = "Update"				
				$Previous_Button.IsEnabled = $True	

				$Main_Buttons.Margin = "-144,0,0,0"
				
			} 			

		} 	
})			
		
$OD_Migration_Btn_Next.Add_Click({
	If(($FlipView.SelectedIndex) -eq 0)
		{
			$Check_WMI_Battery = (get-wmiobject win32_battery)
			$estimatedchargeremaining = $Check_WMI_Battery.estimatedchargeremaining
			$BatteryStatus = $Check_WMI_Battery.BatteryStatus
			
			If($BatteryStatus -ne 2)
				{
					[MahApps.Metro.Controls.Dialogs.DialogManager]::ShowModalMessageExternal($Form,"Battery warning","Your device is running on battery.`nPlease connect the AC adapter to your PC to start the update.")

	
					Write_Log -Message_Type "INFO" -Message "Your device is running on battery."
				}
			Else
				{
					If($estimatedchargeremaining -lt 50)
						{							
							[MahApps.Metro.Controls.Dialogs.DialogManager]::ShowModalMessageExternal($Form,"Battery warning","The current percentage of your device battery is $estimatedchargeremaining %.`nRequired battery level is 50% to continue the update process.")							
							Write_Log -Message_Type "INFO" -Message "The current percentage of your device battery is $estimatedchargeremaining %"
						}				
					Else
						{				
							Write_Log -Message_Type "INFO" -Message "Computer is connected on AC without enough batteru"
							Write_Log -Message_Type "INFO" -Message "Going to the next screen"
							($FlipView.SelectedIndex) = 1
						}
				}		
		}
	ElseIf(($FlipView.SelectedIndex) -eq 1)
		{			
			$okAndCancel = [MahApps.Metro.Controls.Dialogs.MessageDialogStyle]::AffirmativeAndNegative  
			$Button_Style = [MahApps.Metro.Controls.Dialogs.MetroDialogSettings]::new()
			$Button_Style.AffirmativeButtonText = "Update and restart"
			$Button_Style.NegativeButtonText = "Cancel"		
			$result = [MahApps.Metro.Controls.Dialogs.DialogManager]::ShowModalMessageExternal($Form,"Restart of your computer","A restart of your device is required to finalize the process.`n`nBy clicking on « Update and restart  » your computer will restart in the next 5 minutes.`n`nDo not forget to save your work before clicking on Restart !",$okAndCancel, $Button_Style)   
			If($result -eq "Affirmative")
				{
					new-item $User_Continue_Process_File -Type File		
					start-process -WindowStyle hidden powershell.exe "$Current_Folder\Update_BIOS.ps1" 		
					Write_Log -Message_Type "INFO" -Message "User started the update process"										
					$Form.Close()			
				}		
		}
})		

$Later_Btn.Add_Click({
	$Form.Close()
})

$Form.Add_Closing({
	If(!(test-path $User_Continue_Process_File))
		{
			$okAndCancel = [MahApps.Metro.Controls.Dialogs.MessageDialogStyle]::AffirmativeAndNegative  
			$Button_Style = [MahApps.Metro.Controls.Dialogs.MetroDialogSettings]::new()
			$Button_Style.AffirmativeButtonText = "Do it later"
			$Button_Style.NegativeButtonText = "Continue"				
			$result = [MahApps.Metro.Controls.Dialogs.DialogManager]::ShowModalMessageExternal($Form,"Canceling the update","If cancel the update install, this warning will be dislayed again later (approximatively 3 hours).`n`nDo you want to cancel the update process ?`n`nClick on « Do it later » to be display the update warning later.`nClick on « Continue » to continue the install the update.",$okAndCancel, $Button_Style)   				
			If($result -eq "Affirmative")
				{
					Write_Log -Message_Type "INFO" -Message "The user canceled the update"	
					Remove-item $BIOS_Update_Folder -Force -Recurse					
					$Form.Close()
				}	
			Else
				{
					$_.Cancel = $True						
				}
		}
})

$OD_Migration_Btn_Previous.Add_Click({
	If(($FlipView.SelectedIndex) -eq 2)
		{
			($FlipView.SelectedIndex) = 1
		}
	ElseIf(($FlipView.SelectedIndex) -eq 1)
		{
			($FlipView.SelectedIndex) = 0
		}
})			

$Form.ShowDialog() | Out-Null