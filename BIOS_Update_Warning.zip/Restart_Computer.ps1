$Get_MTM = ((Get-CimInstance Win32_ComputerSystem).Model.SubString(0, 4)).Trim()
$Log_File = "$env:SystemDrive\Windows\Debug\Remediation_BIOS_Update_$Get_MTM.log"
If(!(test-path $Log_File)){new-item $Log_File -type file -force}

Function Write_Log
	{
		param(
		$Message_Type,	
		$Message
		)
		
		$MyDate = "[{0:MM/dd/yy} {0:HH:mm:ss}]" -f (Get-Date)		
		Add-Content $Log_File  "$MyDate - $Message_Type : $Message"		
		write-host  "$MyDate - $Message_Type : $Message"		
	}

Write_Log -Message_Type "INFO" -Message "Redémarrage en cours"	

shutdown /r /f /t 300